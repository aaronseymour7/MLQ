#!/usr/bin/env python3
import os
import sys
import argparse
import pennylane as qml

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache-dir", required=True, help="Shared cache dir (e.g., /ccsopen/home/gvk/defiant/pennylane_data)")
    ap.add_argument("--mols", nargs="+", default=["H2"], help="Molecule names to cache (e.g., H2 CO LiH)")
    args = ap.parse_args()

    os.environ["PENNYLANE_DATA_DIR"] = args.cache_dir
    print("PENNYLANE_DATA_DIR =", os.environ["PENNYLANE_DATA_DIR"])
    print("Will cache:", args.mols)

    failed = []
    for mol in args.mols:
        try:
            print(f"\n==> Caching {mol} ...")
            ds = qml.data.load("qchem", molname=mol)
            # touch something to ensure dataset is actually opened
            names = [d.molname for d in ds]
            print("Loaded:", names)
        except Exception as e:
            print(f"[FAILED] {mol}: {repr(e)}", file=sys.stderr)
            failed.append(mol)

    if failed:
        print("\nSome molecules failed:", failed, file=sys.stderr)
        sys.exit(2)

    print("\nAll requested molecules cached successfully.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
