#!/usr/bin/env python3
import os
import sys
import glob
import argparse

def assert_cache_present(cache_dir: str, mols: list[str]) -> None:
    """
    Fail fast if cache doesn't contain expected qchem h5 files.
    We intentionally do NOT attempt any download on compute nodes.
    """
    if not os.path.isdir(cache_dir):
        raise RuntimeError(f"Cache dir does not exist: {cache_dir}")

    # Find any qchem .h5 under cache_dir
    h5_all = glob.glob(os.path.join(cache_dir, "**", "*.h5"), recursive=True)
    if len(h5_all) == 0:
        raise RuntimeError(
            f"No .h5 files found under {cache_dir}. "
            "Run warmup_qchem_cache.py on a login/DTN node first."
        )

    # Optional: check each mol has at least one matching h5 file
    missing = []
    for mol in mols:
        hits = glob.glob(os.path.join(cache_dir, "**", f"*{mol}*.h5"), recursive=True)
        if len(hits) == 0:
            missing.append(mol)

    if missing:
        raise RuntimeError(
            f"Cache seems incomplete. Missing molecules={missing}. "
            "Run warmup_qchem_cache.py on login/DTN to download them."
        )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache-dir", required=True)
    ap.add_argument("--mols", nargs="+", default=["H2"])
    ap.add_argument("--entry", default="main.py", help="Your main entry script")
    args = ap.parse_args()

    # Force PennyLane to use this cache dir
    os.environ["PENNYLANE_DATA_DIR"] = args.cache_dir

    print("PENNYLANE_DATA_DIR:", os.environ["PENNYLANE_DATA_DIR"])
    print("Offline molecules required:", args.mols)

    # Do NOT set any proxy here. We want fully-offline behavior.
    # (If proxies exist in environment, that is fine, but we never depend on them.)

    assert_cache_present(args.cache_dir, args.mols)
    print("Cache check: OK (will run offline).")

    # Run user's main script in the same process (so imports/env stay intact)
    entry_path = args.entry
    if not os.path.exists(entry_path):
        raise RuntimeError(f"Entry script not found: {entry_path}")

    # Execute entry script
    with open(entry_path, "rb") as f:
        code = compile(f.read(), entry_path, "exec")
    globals_dict = {"__name__": "__main__", "__file__": entry_path}
    exec(code, globals_dict, globals_dict)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("OFFLINE RUN FAILED:", repr(e), file=sys.stderr)
        sys.exit(1)
