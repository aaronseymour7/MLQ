import numpy as np
import torch
import pennylane as qml

from models.gpt import GPTQE, GPTConfig
from utils.molecule_data import generate_ucc_operator_pool

def build_h2_hamiltonian(R, basis="sto-3g", charge=0, mult=1):
    symbols = ["H", "H"]
    coords = np.array([[0.0, 0.0, -R/2], [0.0, 0.0, R/2]], dtype=float)

    mol = qml.qchem.Molecule(symbols, coords, charge=charge, mult=mult, basis_name=basis, unit="angstrom")
    H, n_qubits = qml.qchem.molecular_hamiltonian(mol)
    n_elec = mol.n_electrons
    n_orb = mol.n_orbitals
    hf_state = qml.qchem.hf_state(n_elec, 2 * n_orb)
    return H, n_qubits, hf_state, n_elec, 2 * n_orb

def get_energy_for_opseq(op_seq, hamiltonian, init_state, num_qubits, shots=1024):
    dev = qml.device("default.qubit", wires=num_qubits, shots=shots)

    @qml.qnode(dev)
    def circuit(ops):
        qml.BasisState(init_state, wires=range(num_qubits))
        for op in ops:
            qml.apply(op)
        return qml.expval(hamiltonian)

    return np.array([circuit(ops).item() for ops in op_seq])

def main():
    op_times = np.sort(np.logspace(-2, 0, num=8)) / 160

    H_train, nq_train, hf_train, nelec_train, nqb_excite = build_h2_hamiltonian(R=0.742)
    singles, doubles = qml.qchem.excitations(nelec_train, nqb_excite)
    op_pool = generate_ucc_operator_pool(singles, doubles, op_times, nqb_excite)
    op_pool_size = len(op_pool)
    seq_len = 6

    ckpt = "./checkpoints/seq_len=6/gptqe_best_model.pt"
    device = "cuda" if torch.cuda.is_available() else "cpu"

    gpt = GPTQE(GPTConfig(
        vocab_size=op_pool_size + 1,
        block_size=seq_len,
        n_layer=12,
        n_head=12,
        n_embd=768,
        dropout=0.1,
        bias=False
    )).to(device)

    gpt.load_state_dict(torch.load(ckpt, map_location=device))
    gpt.eval()

    R_eval = 0.3
    H_eval, nq_eval, hf_eval, nelec_eval, nqb_excite_eval = build_h2_hamiltonian(R=R_eval)

    assert nq_eval == nq_train, (nq_eval, nq_train)
    assert nqb_excite_eval == nqb_excite, (nqb_excite_eval, nqb_excite)

    with torch.no_grad():
        gen_tokens, pred_Es = gpt.generate(
            n_sequences=500,
            max_new_tokens=seq_len,
            temperature=0.01,
            device=device
        )

    gen_inds = (gen_tokens[:, 1:] - 1).cpu().numpy()
    gen_inds = np.clip(gen_inds, 0, op_pool_size - 1)
    gen_op_seq = [[op_pool[idx] for idx in seq] for seq in gen_inds]

    true_Es = get_energy_for_opseq(gen_op_seq, H_eval, hf_eval, nq_eval).reshape(-1, 1)
    pred_Es = pred_Es.cpu().numpy()

    print("R_eval =", R_eval)
    print("min true energy among generated sequences:", true_Es.min())
    print("min predicted energy:", pred_Es.min())

if __name__ == "__main__":
    main()
