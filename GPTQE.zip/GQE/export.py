export PENNYLANE_DATA_DIR=/ccsopen/home/gvk/defiant/pennylane_data  
source /ccsopen/home/gvk/defiant/GQE/bin/activate
python - << 'PY'
import pennylane as qml
qml.data.load("qchem", molname="H2")
print("cached")
PY
