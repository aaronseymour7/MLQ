#!/bin/bash
#SBATCH --job-name=GQE
#SBATCH --partition=gpu_p
#SBATCH --nodes=1
#SBATCH --gres=gpu:1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16gb
#SBATCH --time=12:00:00
#SBATCH --output=output-%j.out
#SBATCH --error=err-%j.out

module purge
source ~/sm-env/bin/activate
export PENNYLANE_DATA_DIR=/home/ads09449/GQE/datasets

python main.py
