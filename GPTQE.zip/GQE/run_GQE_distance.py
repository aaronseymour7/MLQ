import numpy as np
import torch
import pennylane as qml
import matplotlib.pyplot as plt
import csv

from models.gpt import GPTQE, GPTConfig
from utils.molecule_data import generate_ucc_operator_pool

# =========================
# USER SETTINGS (EDIT HERE)
# =========================
R_list = np.linspace(0.5,4,15)  # Angstrom
ckpt_path = "./checkpoints/seq_len=6/gptqe_best_model.pt"

seq_len = 6
n_samples_per_R = 500
temperature = 0.01

basis = "sto-3g"
shots = None          # None = analytic(statevector). Set e.g. 2048 for sampling.
seed = 0

out_csv = "pes.csv"
out_png = "pes.png"
# =========================


def build_h2_hamiltonian(R_angstrom: float, basis: str = "sto-3g", charge: int = 0, mult: int = 1):
    symbols = ["H", "H"]
    coords = np.array([[0.0, 0.0, -R_angstrom / 2.0],
                       [0.0, 0.0,  R_angstrom / 2.0]], dtype=float)

    mol = qml.qchem.Molecule(
        symbols=symbols,
        coordinates=coords,
        charge=charge,
        mult=mult,
        basis_name=basis,
        unit="angstrom",
        name="H2"
    )
    H, n_qubits = qml.qchem.molecular_hamiltonian(mol)

    n_elec = mol.n_electrons
    n_orb = mol.n_orbitals
    n_qubits_excite = 2 * n_orb

    hf_state = qml.qchem.hf_state(n_elec, n_qubits_excite)
    return H, n_qubits, hf_state, n_elec, n_qubits_excite


def make_energy_qnode(H, hf_state, n_qubits, shots=None):
    dev = qml.device("default.qubit", wires=n_qubits, shots=shots)

    @qml.qnode(dev)
    def circuit(op_list):
        qml.BasisState(hf_state, wires=range(n_qubits))
        for op in op_list:
            qml.apply(op)
        return qml.expval(H)

    return circuit


def load_gptqe_checkpoint(ckpt_path: str, op_pool_size: int, seq_len: int, device: str):
    cfg = GPTConfig(
        vocab_size=op_pool_size + 1,
        block_size=seq_len,
        n_layer=12,
        n_head=12,
        n_embd=768,
        dropout=0.1,
        bias=False
    )
    model = GPTQE(cfg).to(device)
    sd = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(sd)
    model.eval()
    return model


def main():
    np.random.seed(seed)
    torch.manual_seed(seed)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # --- Build operator pool exactly like training (UCC singles/doubles + op_times grid) ---
    # Use a reference geometry; for H2 the electron/orbital counts don't change with R.
    H_ref, nq_ref, hf_ref, n_elec_ref, n_q_excite_ref = build_h2_hamiltonian(0.742, basis=basis)

    op_times = np.sort(np.logspace(-2, 0, num=8)) / 160.0
    singles, doubles = qml.qchem.excitations(n_elec_ref, n_q_excite_ref)
    op_pool = generate_ucc_operator_pool(singles, doubles, op_times, n_q_excite_ref)
    op_pool_size = len(op_pool)

    gpt = load_gptqe_checkpoint(ckpt_path, op_pool_size, seq_len, device)

    rows = []
    for R in R_list:
        H, nq, hf_state, n_elec, n_q_excite = build_h2_hamiltonian(R, basis=basis)

        # sanity checks
        if n_q_excite != n_q_excite_ref:
            raise RuntimeError(f"Excitation qubits changed at R={R}: {n_q_excite} vs ref {n_q_excite_ref}")

        energy_qnode = make_energy_qnode(H, hf_state, nq, shots=shots)

        # --- sample operator sequences ---
        with torch.no_grad():
            gen_tokens, pred_E = gpt.generate(
                n_sequences=int(n_samples_per_R),
                max_new_tokens=int(seq_len),
                temperature=float(temperature),
                device=device
            )

        # token convention: first is start; ops are token-1
        gen_inds = (gen_tokens[:, 1:] - 1).detach().cpu().numpy()
        gen_inds = np.clip(gen_inds, 0, op_pool_size - 1)

        op_seqs = [[op_pool[idx] for idx in seq] for seq in gen_inds]

        true_E = np.empty((len(op_seqs),), dtype=float)
        for i, ops in enumerate(op_seqs):
            true_E[i] = float(energy_qnode(ops))

        row = {
            "R": float(R),
            "E_min": float(true_E.min()),
            "E_mean": float(true_E.mean()),
            "E_std": float(true_E.std(ddof=0)),
            "E_pred_min": float(pred_E.min().item()),
            "E_pred_mean": float(pred_E.mean().item()),
        }
        rows.append(row)
        print(f"R={R:.4f}  E_min={row['E_min']:.10f}  E_mean={row['E_mean']:.10f}")

    # --- save CSV ---
    with open(out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    # --- plot PES (min energy curve) ---
    Rv = np.array([r["R"] for r in rows], dtype=float)
    Ev = np.array([r["E_min"] for r in rows], dtype=float)

    plt.figure()
    plt.plot(Rv, Ev, marker="o")
    plt.xlabel("H–H distance R (Å)")
    plt.ylabel("Energy (Hartree)")
    plt.title("H2 PES from GPTQE-generated operator sequences (min over samples)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(out_png, dpi=200)

    print(f"\nSaved: {out_csv}")
    print(f"Saved: {out_png}")


if __name__ == "__main__":
    main()
