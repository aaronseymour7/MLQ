import os
import glob
import h5py
from pennylane.data import Dataset
from typing import Optional

def _find_local_qchem_h5(cache_root: str, molname: str) -> str:
    # 보통 구조: <cache_root>/qchem/H2/STO-3G/0.742/H2_STO-3G_0.742.h5
    patt = os.path.join(cache_root, "qchem", molname, "**", f"{molname}_*.h5")
    hits = glob.glob(patt, recursive=True)

    # 혹시 cache_root가 datasets가 아니라 상위여서 구조가 다르면 느슨하게 한번 더
    if not hits:
        patt2 = os.path.join(cache_root, "**", "qchem", molname, "**", f"{molname}_*.h5")
        hits = glob.glob(patt2, recursive=True)

    if not hits:
        raise FileNotFoundError(
            f"No local qchem h5 for molname='{molname}' under cache_root='{cache_root}'.\n"
            f"Tried patterns:\n  {patt}\n  {patt2}"
        )

    return sorted(hits)[0]

def load_qchem_local(molname: str, cache_root: Optional[str] = None):
    """
    Completely offline loader for PennyLane qchem datasets.
    Does NOT call datasets.cloud.pennylane.ai (no foldermap.json).
    Returns: [Dataset] (list to mimic qml.data.load)
    """
    if cache_root is None:
        cache_root = os.environ.get("PENNYLANE_DATA_DIR", None)
    if not cache_root:
        raise RuntimeError("Set PENNYLANE_DATA_DIR to your local datasets directory (offline cache root).")

    h5_path = _find_local_qchem_h5(cache_root, molname)

    # IMPORTANT: keep the file handle open by attaching it to the Dataset object
    f = h5py.File(h5_path, "r")
    ds = Dataset(f)
    ds._offline_h5_handle = f   # prevent garbage collection / premature close

    return [ds]
